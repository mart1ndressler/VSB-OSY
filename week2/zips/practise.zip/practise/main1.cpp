#include "header1.h"

int main() 
{
    input();
    return 0;
}