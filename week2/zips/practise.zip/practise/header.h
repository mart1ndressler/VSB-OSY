#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <stdio.h>
#include <string>

void output(int t_L, int t_N);
#endif